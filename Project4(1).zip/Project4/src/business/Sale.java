package business;

public class Sale {
    //declare variables
    private double car_price;
    private double trade_in;
    private boolean blnCD, blnGPS, blnCustomWheel, blnRustFree;
    
    //declare constants
    private final double CD_price=325.50;
    private final double GPS_price=1200;
    private final double RUST_FREE_price=625.99;
    private final double CUSTOM_WHEEL_price=625.99;
    private final double SALES_TAX_RATE=0.08;
    private double dblSubtotal,dblFeatures,dblSales_Tax_Amt,dblAmt_due;
    //static variables
    static int intSalesCount;
    static double dblGrandTotal, dblTradeInTotal;
    
    //constructor
    public Sale()
    { 
        car_price=0; 
        trade_in=0;
        blnCD=false;
        blnGPS=false;
        blnCustomWheel=false;
        blnRustFree=false;
            
    } 
    //constructor
    public Sale(double car_price, double trade_in,
            boolean blnCD, boolean blnCustomWheel, 
            boolean blnGPS,boolean blnRustFree)
    {
        this.car_price = car_price;
        this.trade_in = trade_in;
        this.blnCD = blnCD;
        this.blnCustomWheel = blnCustomWheel;
        this.blnGPS = blnGPS;
        this.blnRustFree = blnRustFree;
    }
    /**
     * @return the car_price
     */
    public double getCar_price() {
        return car_price;
    }

    /**
     * @param car_price the car_price to set
     */
    public void setCar_price(double car_price) {
        this.car_price = car_price;
    }

    /**
     * @return the trade_in
     */
    public double getTrade_in() {
        return trade_in;
    }

    /**
     * @param trade_in the trade_in to set
     */
    public void setTrade_in(double trade_in) {
        this.trade_in = trade_in;
    }

    /**
     * @return the blnCD
     */
    public boolean isBlnCD() {
        return blnCD;
    }

    /**
     * @param blnCD the blnCD to set
     */
    public void setBlnCD(boolean blnCD) {
        this.blnCD = blnCD;
    }

    /**
     * @return the blnGPS
     */
    public boolean isBlnGPS() {
        return blnGPS;
    }

    /**
     * @param blnGPS the blnGPS to set
     */
    public void setBlnGPS(boolean blnGPS) {
        this.blnGPS = blnGPS;
    }

    /**
     * @return the blnCustomWheel
     */
    public boolean isBlnCustomWheel() {
        return blnCustomWheel;
    }

    /**
     * @param blnCustomWheel the blnCustomWheel to set
     */
    public void setBlnCustomWheel(boolean blnCustomWheel) {
        this.blnCustomWheel = blnCustomWheel;
    }

    /**
     * @return the blnRustFree
     */
    public boolean isBlnRustFree() {
        return blnRustFree;
    }

    /**
     * @param blnRustFree the blnRustFree to set
     */
    public void setBlnRustFree(boolean blnRustFree) {
        this.blnRustFree = blnRustFree;
    } 
    public double getSubtotal() 
    {
        double subtotal=0;
        subtotal=car_price-trade_in+getFeaturesTotal();
        return subtotal;
    } 
    public double getFeaturesTotal()
    { 
        if (blnCD ==true )
        {
           dblFeatures += CD_price;      
        } 
        if (blnGPS==true) 
        {
            dblFeatures+=GPS_price;
            
        } 
        if (blnCustomWheel) 
        {
            dblFeatures+=CUSTOM_WHEEL_price;
        }
        if (blnRustFree) 
        {
            dblFeatures+=RUST_FREE_price;
        }
        return dblFeatures;
    } 
    public double getSalesTaxAmt() 
    {
       dblSales_Tax_Amt=getSubtotal()*SALES_TAX_RATE;
       return dblSales_Tax_Amt;
    }
    public double getAmtDue() 
    {
        //Amtdue=subtotal+sales_tax
        dblAmt_due=getSubtotal()+getSalesTaxAmt(); 
        intSalesCount++;
        dblGrandTotal+=dblAmt_due;
        trade_in+=trade_in;
        return dblAmt_due;
    }
    
}
